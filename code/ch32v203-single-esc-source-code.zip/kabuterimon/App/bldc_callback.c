#include "bldc_callback.h"
#include "bldc_mos_ctrl.h"
#include "bldc_zero_cross.h"
#include "bldc_tim_cnt.h"
#include "user_lib.h"

void bldc_change_phase_callback(bldc_ctrl_t *ctrl)
{
    switch (ctrl->status) {
        case DRAG:
        case CLOSED_LOOP:
            bldc_mos_change_phase(ctrl);
            bldc_zero_cross_switch(ctrl);
            bldc_tim_cnt_enable(ctrl, BLDC_STEP_CNT_MAX);
            break;
        default:
            break;
    }
}

void bldc_zero_cross_callback(bldc_ctrl_t *ctrl)
{
    if (ctrl->hTIM_cnt->CNT < ctrl->step_cnt / BLDC_STEP_CNT_MIN_ADV) {
        return;
    }
    switch (ctrl->status) {
        case DRAG:
            // no break
        case CLOSED_LOOP:
            ctrl->change_phase_fail_num = 0;
            ctrl->change_phase_ok_num++;
            ctrl->step_cnt = (ctrl->step_cnt * 31 + ctrl->hTIM_cnt->CNT) / 32;
            bldc_zero_cross_disable(ctrl);
            if (ctrl->status == DRAG) {
                bldc_tim_cnt_enable(ctrl, BLDC_STEP_CNT_DRAG);
            } else {
                bldc_tim_cnt_enable(ctrl, ctrl->step_cnt / 2);
            }
            break;
        default:
            break;
    }
}

void bldc_time_out_callback(bldc_ctrl_t *ctrl)
{
    switch (ctrl->status) {
        case DRAG:
            ctrl->change_phase_ok_num = 0;
            // no break
        case CLOSED_LOOP:
            ctrl->change_phase_fail_num++;
            ctrl->step_cnt = (ctrl->step_cnt * 63 + ctrl->hTIM_cnt->CNT) / 64;
            bldc_change_phase_callback(ctrl);
            break;
        default:
            break;
    }
}

void bldc_pwm_input_callback(bldc_ctrl_t *ctrl)
{
    static uint32_t last_high = 1145;   //解锁后怠速PWM高电平宽度是1.145ms,总脉宽5ms(200Hz)
    static uint32_t last_period = 200;
    uint32_t period = TIM_GetCapture1(ctrl->hTIM_input) + 1;    //ctrl.hTIM_input就是TIM2;TIM_GetCapture1返回CCR1,并将cnt置0;上升沿
    uint32_t high   = TIM_GetCapture2(ctrl->hTIM_input) + 1;    //TIM_GetCapture2返回CCR2;下降沿

    /**** 处理PWM偶发性跳变的问题 ****/
    // if (abs((int32_t)high - (int32_t)last_high) > PWM_ERROR_Threshold) {
    if (period < PWM_ERROR_PERIOD_Threshold) {      //正常的period==5000,freq==200
        period = last_period;   //每次bug出现会进这个if两次，都使用bug出现前的那个周期的period和high
        high = last_high;
    } else {
        last_period = period;
        last_high = high;
    }

    uint32_t freq   = 1000000 / period;//时钟频率1_000_000/period
    uint32_t duty   = 0;

    if( (freq > 20) && (freq < 400) && (high < 3000) && (high > 1000) ) {
        if(high >= 2000) {
            high = 1000;
        } else {
            high -= 1000;
        }
        duty = high * BLDC_DUTY_MAX / 1000;
        if (duty < ctrl->duty.value_min && ctrl->status == IDLE) {
            ctrl->duty.value = 0;
        } else if (ctrl->status == DRAG) {
            ctrl->duty.value = ctrl->duty.value_min;
        } else {
            ramp_int32_update(&ctrl->duty, duty);
        }
    } else {
        ctrl->status = IDLE;
        ctrl->status_prev = IDLE;
        ctrl->duty.value = 0;
    }

}

void bldc_pwm_input_timeout_callback(bldc_ctrl_t *ctrl)
{
    ctrl->status = IDLE;
    ctrl->status_prev = IDLE;
    ctrl->duty.value = 0;
}


